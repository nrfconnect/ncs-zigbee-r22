ZBOSS NCP Host
##############

The ZBOSS NCP Host implements the network co-processor (NCP) design for Nordic Semicondutor's nRF52833 DK, nRF52840 DK, and nRF52840 Dongle.
The package is made of the following parts:

* NCP SoC firmware (HEX binary file)
* ZBOSS libraries for the NCP host application
* ZBOSS sources to rebuild the libraries for the selected NCP host

Hardware and software requirements
**********************************

You need the following hardware and software for using the ZBOSS NCP Host package:

* Operating system compatible with the 64-bit Ubuntu 22.04 Linux OS, which was used for building and testing the precompiled ZBOSS libraries in the package
* nRF52833 DK (PCA10100), nRF52840 DK (PCA10056), or nRF52840 Dongle (PCA10059)

Documentation
*************

To read more about the NCP SoC firmware and the ZBOSS libraries for the NCP host application,
including how to build the NCP host sample applications, see the online ZBOSS NCP Host documentation at https://ncsdoc.z6.web.core.windows.net/zboss/3.11.6.0/zboss_ncp_host_intro.html.
