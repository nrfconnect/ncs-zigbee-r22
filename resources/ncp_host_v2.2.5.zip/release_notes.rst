ZBOSS NCP Host release notes
############################

For the release notes, see the online ZBOSS NCP Host documentation at https://ncsdoc.z6.web.core.windows.net/zboss/3.11.6.0/zboss_ncp_host_intro.html
